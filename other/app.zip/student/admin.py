from django.contrib import admin

# Register your models here.

from .models import Guruh, Jinsi, Viloyatlar, Talaba, Murojaat

class TalabaAdmin(admin.ModelAdmin):
    list_filter = ["jinsi", "viloyat"]
    list_display = ["familiya", "ism", "guruh", "telefon_raqami", "viloyat"]
    search_fields = ["familiya"]

admin.site.register(Murojaat)
admin.site.register(Guruh)
admin.site.register(Jinsi)
admin.site.register(Viloyatlar)
admin.site.register(Talaba, TalabaAdmin)