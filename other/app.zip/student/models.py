from django.db import models


class Guruh(models.Model):
    guruh_raqami = models.CharField(max_length=100)
    guruh_rahbari = models.CharField(max_length=200)

    class Meta:
        managed = True
        db_table = 'guruh'
        verbose_name = "Guruh"
        verbose_name_plural = "Guruhlar"

    def __str__(self):
        return self.guruh_raqami


class Jinsi(models.Model):
    jins = models.CharField(max_length=5)

    class Meta:
        managed = True
        db_table = 'jinsi'
        verbose_name = "Jins"
        verbose_name_plural = "Jinslar"

    def __str__(self):
        return self.jins



class Viloyatlar(models.Model):
    viloyat_nomi = models.CharField(max_length=100)

    class Meta:
        managed = True
        db_table = 'viloyatlar'
        verbose_name = "Viloyat"
        verbose_name_plural = "Viloyatlar"

    def __str__(self):
        return self.viloyat_nomi


class Talaba(models.Model):
    familiya = models.CharField(max_length=50)
    ism = models.CharField(max_length=50)
    otasining_ismi = models.CharField(max_length=50)
    tavallud_kuni = models.DateField()
    yashash_manzili = models.CharField(max_length=200)
    telefon_raqami = models.CharField(max_length=100)
    guruh = models.ForeignKey('Guruh', on_delete=models.DO_NOTHING, db_column='guruh', related_name= 'all_students')
    jinsi = models.ForeignKey('Jinsi', on_delete=models.DO_NOTHING, db_column='jinsi')
    viloyat = models.ForeignKey('Viloyatlar', on_delete=models.DO_NOTHING, db_column='viloyat')

    class Meta:
        managed = True
        db_table = 'talaba'
        ordering = ["familiya"]
        verbose_name = "Talaba"
        verbose_name_plural = "Talabalar"


    def __str__(self):
        return self.familiya
    

class Murojaat(models.Model):
    fio = models.CharField(max_length=50, verbose_name='Familiya Ismingiz')
    telefon = models.CharField(max_length=50)
    viloyat = models.ForeignKey('Viloyatlar', on_delete=models.DO_NOTHING, db_column='viloyat')
    time = models.DateTimeField(db_comment="Yaratish (o'zgartirish) vaqti", auto_now_add=True)

    class Meta:
        managed = True
        db_table = 'murojaat'
        verbose_name = "Murojaat"
        verbose_name_plural = "Murojaatlar"

    def __str__(self):
        return self.fio