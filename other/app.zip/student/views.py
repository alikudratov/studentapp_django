from django.shortcuts import render, redirect
from .models import Talaba, Guruh
from .forms import MurojaatForm
from django.contrib import messages


def index(request):
    count = Talaba.objects.count()
    
    students = Talaba.objects.all()

    form = MurojaatForm(request.POST or None)
    
    if form.is_valid():
            form.save()
            messages.success(request, 'Murojaat muvaffaqiyatli yuborildi!')

    return render(request,'index.html',{'count':count, 'students':students, 'form':form})

def testpage(request, guruh):
      group = Guruh.objects.get(id=guruh)
      return render(request, 'test.html',{'allstudents':group.all_students.all()})