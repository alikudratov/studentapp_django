from django.contrib import admin
from django.urls import path
from student.views import index, testpage

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index),
    path('testpage/<int:guruh>', testpage),

]

admin.site.site_header = "Talabalar MB"
admin.site.site_title = "Talabalar MB"
admin.site.index_title = "Talabalar MB"